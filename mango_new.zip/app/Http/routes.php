<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::get('/', function () {
//    return view('welcome');
});
Route::post('/user/register/new', ['uses'=>'UsersController@create','as'=>'user_create']);
Route::post('/Clients_list/add_client/add', ['uses'=>'ClientController@add_client','as'=>'client_create']);
Route::get('/user/register','UsersController@RegisterView');
Route::get('/user/login','LoginController@LoginView');
Route::get('/Clients_list','ClientController@ListView');
Route::get('/Clients_list/add_client','ClientController@AddClientView');

Route::post('user/login/do',['uses'=>'LoginController@postLogin','as'=>'user_login']);
