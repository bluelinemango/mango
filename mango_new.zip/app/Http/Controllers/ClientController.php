<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ListView(){
        if(Auth::check()){
            $clients = Client::where('user_id',Auth::user()->id)->get();
            return view('client.list')->with('clients',$clients)->with('permission',\Permission_Check::getPermission());
        }else{
            return Redirect::to('/user/login');
        }

    }
    public function AddClientView(){
        if(Auth::check()){
            foreach(\Permission_Check::getPermission() as $per_obj){
                if($per_obj->getPermission->name == 'ADD_CLIENT'){
                    return view('client.add_client');
                }else{
                    return Redirect::back();
                }
            }
        }else{
            return Redirect::back();
        }
    }
    public function add_client(Request $request){
        $validate=\Validator::make($request->all(),['name' => 'required']);
        if($validate->passes()) {
//            $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=6LdOJAcTAAAAAFnwVTSg4GLCuDhvXXTOaGlgj1sj&response=' . $request->input('g-recaptcha-response'));
//            $captchaCheck = json_decode($response);
//            if ($captchaCheck->{'success'} == true) {
                $client=new Client();
                $client->name=$request->input('name');
                $client->company=$request->input('company');
                $client->user_id=Auth::user()->id;
                $client->save();
                return Redirect::back()->withErrors(['success'=>true,'msg'=>"Client added successfully"]);
//            }
//            return \Redirect::back()->withErrors(['success'=>false,'msg'=> 'ﮐﺪ اﻣﻨﯿﺘﯽ ﺭا ﻭاﺭﺩ ﮐﻨﯿﺪ']);
        }
        //return print_r($validate->messages());
        return Redirect::back()->withErrors(['success'=>false,'msg'=>$validate->messages()->all()])->withInput();
    }
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
