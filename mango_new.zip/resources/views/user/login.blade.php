@extends('Layout')
@section('siteTitle')Login Form @endsection

@section('content')
    <div class="row content">
        <!-- Main Content -->
        <section class="main-content col-lg-9 col-md-9 col-sm-9">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 ">
                    <div class="carousel-heading no-margin">
                        <h4><i class="glyphicon glyphicon-log-in"></i>login Form</h4>
                    </div>
                    <div class="page-content">
                        <div class="row">
                            <div class="col-md-12">
                                @if(isset($errors))
                                    @foreach($errors->get('msg') as $error)
                                        <div class="alert alert-{{($errors->get('success')[0] == true)?'success':'danger'}} alert-dismissible" role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <strong>{{$error}}</strong>
                                        </div>
                                    @endforeach
                                @endif
                                <form class="form-horizontal" method="post"
                                      action="{{URL::route('user_login')}}">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Email</label>

                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" value="{{old('email')}}"
                                                   name="email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Password</label>

                                        <div class="col-sm-10">
                                            <input type="password" class="form-control" name="password">
                                        </div>
                                    </div>
                                    <div class="col-md-12 ">
                                        <input type="submit" class="btn btn-primary btn-block" value="Signe IN">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- /Main Content -->
        <!-- Sidebar -->
        <aside class="sidebar col-lg-3 col-md-3 col-sm-3 ">
        </aside>
        <!-- /Sidebar -->
    </div>
    <!-- /Content -->
@endsection