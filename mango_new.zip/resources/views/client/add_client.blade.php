@extends('Layout')
@section('siteTitle')Add Client @endsection
@section('content')
    <style>
        #registerForm input{
            margin-bottom: 1em;;
        }
    </style>
    <!-- Content -->
    <div class="row content">
            <span ng-app="myApp" ng-controller="index">
            <section class="main-content col-lg-9 col-md-9 col-sm-9">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 ">
                        <div class="carousel-heading no-margin">
                            <h4><i class="glyphicon glyphicon-user"></i> Add Client</h4>
                        </div>
                        <div class="page-content">
                            <div class="row">
                                <div class="col-md-12">
                                    @if(isset($errors))
                                        @foreach($errors->get('msg') as $error)
                                            <div class="alert alert-{{($errors->get('success')[0] == true)?'success':'danger'}} alert-dismissible" role="alert">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <strong>{{$error}}</strong>
                                            </div>
                                        @endforeach
                                    @endif
                                    @if(Session::has('CaptchaError'))
                                        <ul>
                                            <li>{{Session::get('CaptchaError')}}</li>
                                        </ul>
                                    @endif

                                    <form class="form-horizontal" action="{{URL::route('client_create')}}" method="post" >
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">name <i style="color:#F00" >*</i> </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="name" placeholder="Please Fill your email address" >
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Company name <i style="color:#F00" >*</i> </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="company" placeholder="Please Fill your company" >
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-primary btn-block" style="font-size:18px; font-weight:bolder;" value="submit">
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
            </span>

        <!-- /Main Content -->
        <!-- Sidebar -->
        <aside class="sidebar col-lg-3 col-md-3 col-sm-3 ">
        </aside>
        <!-- /Sidebar -->
    </div>
    <!-- /Content -->
@endsection
@section('FooterScripts')

@endsection