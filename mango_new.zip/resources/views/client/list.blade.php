@extends('Layout')
@section('siteTitle')List Of {{\Illuminate\Support\Facades\Auth::user()->name}} Clients @endsection

@section('content')
    <div class="row content">
        <!-- Main Content -->
        <section class="main-content col-lg-9 col-md-9 col-sm-9">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 ">
                    <div class="carousel-heading no-margin">
                        <h4><i class="glyphicon glyphicon-log-in"></i>List Of {{\Illuminate\Support\Facades\Auth::user()->name}}'s Clients</h4>
                    </div>
                    <div class="page-content">
                        <div class="row">
                            <div class="col-md-12">
                                @if(isset($errors))
                                    @foreach($errors->get('msg') as $error)
                                        <div class="alert alert-{{($errors->get('success')[0] == true)?'success':'danger'}} alert-dismissible" role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <strong>{{$error}}</strong>
                                        </div>
                                    @endforeach
                                @endif

                                <table class="table-bordered">
                                    <thead>
                                        <th>id</th>
                                        <th>name</th>
                                        <th>company</th>
                                        <th>Modify</th>
                                    </thead>
                                    <tbody>
                                        @foreach($clients as $index)
                                            <tr>
                                                <td>{{$index->id}}</td>
                                                <td>{{$index->name}}</td>
                                                <td>{{$index->company}}</td>
                                                <td>
                                                    @foreach($permission as $per_obj)
                                                        @if($per_obj->getPermission->name == 'EDIT_CLIENT')
                                                    <a href="#">Edit</a> |
                                                        @endif
                                                    @endforeach
                                                    <a href="#">Delete</a></td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        {{--{{dd($permission)}}--}}
                        @foreach($permission as $per_obj)
                            @if($per_obj->getPermission->name == 'ADD_CLIENT')
                        <div class="row">
                            <a href="/Clients_list/add_client"><button class="btn btn-primary">Add Client</button></a>
                        </div>
                            @endif
                        @endforeach
                    </div>

                </div>
            </div>
        </section>
        <!-- /Main Content -->
        <!-- Sidebar -->
        <aside class="sidebar col-lg-3 col-md-3 col-sm-3 ">
        </aside>
        <!-- /Sidebar -->
    </div>
    <!-- /Content -->
@endsection