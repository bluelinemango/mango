@include('style.header')
<body>
<!-- Container -->
<div class="container">
    @yield('content')
</div>
<!-- Container -->
@yield('FooterScripts')
</body>
</html>