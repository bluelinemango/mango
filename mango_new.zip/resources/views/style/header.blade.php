<!DOCTYPE html>
<html>
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <meta http-equiv="refresh" content="1500" >
    @yield('metaKeyword')
    @yield('metaDesc')
    <!-- Title -->
    <title>@yield('siteTitle')</title>
    <!-- Stylesheets -->
    <link rel="stylesheet" href="{{cdn("css/bootstrap.min.css")}}">
    {{--<link rel="stylesheet" href="{{cdn("css/one.css")}}">--}}
    @yield('HeaderCss')
    <!--[if lt IE 9]>
    <!--<script src="{{cdn('js/html5shiv.js')}}"></script>-->
    {{--<link rel="stylesheet" href="{{cdn('css/ie.css')}}">--}}
    <![endif]-->
    <!--[if IE 7]>
    <!--<link rel="stylesheet" href="{{cdn('css/fontello-ie7.css')}}">-->
    <![endif]-->
</head>